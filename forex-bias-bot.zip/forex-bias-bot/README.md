# Forex Bias Bot

Sends D1→H4 and W1→D1 bias alerts to Telegram for:

XAUUSD, XAGUSD, US30, NAS100, SPX500, JP225, GER30, BTCUSD, ETHUSD, SOLUSD,
USDJPY, GBPJPY, NZDJPY, EURJPY, VIX25

Data comes from Deriv's free public API (no account needed for price
history) - it was the only source that covers every one of the above
under one roof, including VIX25 (Deriv's synthetic "Volatility 25 Index")
and the stock indices, which most generic market-data APIs don't carry
under those names.

## 1. How it decides an alert

A quick summary of the logic - see the docstrings in `bot/` for the exact
code. Items marked **(confirmed)** were checked against your example
charts; the rest are a best-effort reading of the written rules and are
worth a second look.

- **Key level (confirmed)** - two neighbouring candles. Rising-then-falling
  (A-shape) marks a resistance level at the higher of the two highs;
  falling-then-rising (V-shape) marks a support level at the lower of the
  two lows. Open-Close (two candles the same direction) marks a level at
  the price where the first candle's close meets the second candle's open.
- **Freshness (confirmed)** - a level stops being fresh the moment any
  later candle's wick touches it or trades through it, not only on a
  close through it.
- **Rejection** - the latest closed higher-tf candle touches a fresh level
  and closes back away from it. If it also pushed past the *previous*
  candle's high/low before closing back under/over it, the message notes
  that as the "swept previous candle" variant.
- **Turning point (confirmed)** - a proper swing high/low (a fractal: a
  candle whose high/low beats its immediate neighbour on each side), not
  the raw previous candle.
- **External BO** - the last such swing point *before* price reached the
  key level; confirmed the moment a later lower-tf candle *closes* beyond
  it.
- **Internal BO** - the first such swing point *after* price reached the
  key level (off by default - see `internal_bo_enabled` in
  `config/settings.yaml`).
- **Trend (confirmed)** - break-of-structure: the trend flips the instant
  a candle closes beyond the most recently confirmed swing point on the
  opposite side.
- **ERL** - "external" is read as the *outer edge* of the broader swing
  range (the most extreme opposite-side swing before the key level), as
  distinct from the nearer "internal" levels in between. Flagged taken if
  price has already traded through it by the time the breakout candle
  closes.
- **Next Day Rule** - informational only: did the breakout candle open
  after the rejecting candle had closed.

Dedup: each instrument/pair/bias/BO-type only fires once per distinct
rejection+breakout combination, tracked in `state/last_alerts.json`.

## 2. One-time setup

### a) Get a Deriv app ID (free, no trading account needed for price data)
Register one at <https://api.deriv.com> (takes a minute), or just start
with the public demo app ID `1089` - it works out of the box, but Deriv
may rate-limit it more aggressively under load.

### b) Confirm the exact Deriv symbol codes
The codes in `config/instruments.yaml` are my best guess, written without
being able to call the live API myself. Run this once, from the project
root, before trusting the bot:

```bash
pip install -r requirements.txt
python -m tools.find_symbols
```

It prints the matching Deriv symbols for each instrument. Paste the
confirmed `deriv_symbol` values into `config/instruments.yaml` (the five
stock indices - US30/NAS100/SPX500/JP225/GER30 - are the ones most likely
to need a correction).

### c) Test it locally once
```bash
export TELEGRAM_BOT_TOKEN="your-bot-token"
export TELEGRAM_CHAT_ID="your-chat-or-channel-id"
python -m bot.main
```
Nothing prints beyond a couple of log lines unless there's a live alert to
send right now - that's expected, it's not a demo mode. You can lower
`max_rejection_age_hours` or watch the log lines in `bot/main.py` while
testing.

### d) Add the repo secrets for GitHub Actions
In your GitHub repo → Settings → Secrets and variables → Actions, add:
- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_CHAT_ID`
- `DERIV_APP_ID` (optional - defaults to `1089` if you skip this)

### e) Push and enable Actions
Push this repo to GitHub and open the Actions tab once to confirm the
workflow is enabled. It runs hourly (`.github/workflows/alerts.yml`) and
also supports a manual "Run workflow" button for testing.

Why hourly rather than trying to time it exactly to each H4/D1/W1 close:
the bot tracks the last candle it's already alerted on, so it's safe (and
simpler) to just check often - it only ever acts on newly-closed candles.

### f) Running it as a plain cron job instead (or as well)
Nothing GitHub-specific in the code - `python -m bot.main` with the three
environment variables set is the whole interface. A normal crontab entry
(e.g. `5 * * * * cd /path/to/forex-bias-bot && python -m bot.main`) works
identically on your own machine or server; just don't run both the cron
job and GitHub Actions against the same `state/last_alerts.json` at once,
or point them at different Telegram chats.

## 3. Customising

Everything behavioural lives in `config/settings.yaml`: which timeframe
pairs to scan, the swing-detection width, whether Internal BO alerts are
on, the ERL flag, how much history to pull, and the timezone used for the
"Sent" footer.

## 4. Project layout

```
bot/
  deriv_client.py      Deriv WebSocket API (candles + symbol lookup)
  candles.py           daily -> weekly aggregation
  market_structure.py  swing points + break-of-structure trend
  key_levels.py        A-shape / V-shape / Open-Close KL detection + freshness
  analysis.py          rejection -> breakout -> trend -> ERL -> Alert
  formatting.py        Alert -> Telegram message text
  telegram.py          sendMessage
  config.py, state.py  config + dedupe-state loading
  main.py              entry point
tools/find_symbols.py  one-time Deriv symbol lookup helper
config/                instruments.yaml, settings.yaml
.github/workflows/     the scheduled GitHub Actions job
state/last_alerts.json committed back after each run, for dedupe
```
