"""Run this ONCE to find the exact Deriv symbol codes for your 15
instruments, then paste the confirmed codes into config/instruments.yaml.

The codes already in instruments.yaml are a best guess (made without being
able to call the live API from where this was built) - treat them as
unverified until you've run this and checked them.

Usage:
    python -m tools.find_symbols
"""
import asyncio
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from bot.deriv_client import fetch_active_symbols  # noqa: E402

SEARCH_TERMS = [
    "Gold", "Silver",
    "Wall Street", "Tech 100", "US 500", "S&P",
    "Japan 225", "Germany",
    "Volatility 25",
    "BTC", "ETH", "SOL",
    "USD/JPY", "GBP/JPY", "NZD/JPY", "EUR/JPY",
]


async def main():
    app_id = os.environ.get("DERIV_APP_ID", "1089")
    symbols = await fetch_active_symbols(app_id)

    for term in SEARCH_TERMS:
        print(f"\n== {term} ==")
        needle = term.lower().replace(" ", "").replace("/", "")
        matches = [
            s for s in symbols
            if term.lower() in s.get("display_name", "").lower()
            or needle in s.get("symbol", "").lower()
        ]
        if not matches:
            print("  (no match - try widening the search term)")
        for s in matches:
            print(f"  {s.get('symbol'):<15} {s.get('display_name')}  [{s.get('market_display_name')}]")


if __name__ == "__main__":
    asyncio.run(main())
