"""Candle aggregation helpers."""
from datetime import timedelta
from typing import List

from .models import Candle


def aggregate_to_weekly(daily: List[Candle]) -> List[Candle]:
    """Group daily candles into weekly candles, week starting Monday 00:00 UTC."""
    if not daily:
        return []

    weeks = {}
    order = []
    for c in daily:
        monday = (c.open_time - timedelta(days=c.open_time.weekday())).replace(
            hour=0, minute=0, second=0, microsecond=0
        )
        if monday not in weeks:
            weeks[monday] = []
            order.append(monday)
        weeks[monday].append(c)

    weekly = []
    for monday in order:
        group = sorted(weeks[monday], key=lambda c: c.open_time)
        weekly.append(Candle(
            open_time=monday,
            open=group[0].open,
            high=max(c.high for c in group),
            low=min(c.low for c in group),
            close=group[-1].close,
        ))
    return weekly
