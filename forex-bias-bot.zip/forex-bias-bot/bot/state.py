"""Tracks which alerts have already been sent, so re-running the bot every
hour doesn't resend the same alert while it's still the latest one.

Persisted to state/last_alerts.json, which the GitHub Actions workflow
commits back to the repo after every run (see .github/workflows/alerts.yml).
"""
import json
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATE_PATH = os.path.join(BASE_DIR, "state", "last_alerts.json")


def load_state() -> dict:
    if not os.path.exists(STATE_PATH):
        return {}
    with open(STATE_PATH, "r") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return {}


def save_state(state: dict) -> None:
    os.makedirs(os.path.dirname(STATE_PATH), exist_ok=True)
    with open(STATE_PATH, "w") as f:
        json.dump(state, f, indent=2, sort_keys=True, default=str)


def alert_key(instrument: str, higher_tf: str, lower_tf: str, bias: str, bo_kind: str) -> str:
    return f"{instrument}:{higher_tf}->{lower_tf}:{bias}:{bo_kind}"


def already_sent(state: dict, key: str, fingerprint: str) -> bool:
    return state.get(key) == fingerprint


def mark_sent(state: dict, key: str, fingerprint: str) -> None:
    state[key] = fingerprint
