"""Entry point. Run with: python -m bot.main

Required environment variables:
    TELEGRAM_BOT_TOKEN
    TELEGRAM_CHAT_ID
Optional:
    DERIV_APP_ID   (defaults to Deriv's public demo app id "1089" - fine to
                    start with, but register your own free one at
                    api.deriv.com for anything beyond light testing)
"""
import asyncio
import os
import sys
from datetime import datetime, timedelta, timezone

from .analysis import GRANULARITY_SECONDS, analyse_pair
from .candles import aggregate_to_weekly
from .config import load_instruments, load_settings
from .deriv_client import fetch_candles
from .formatting import format_alert
from .state import already_sent, alert_key, load_state, mark_sent, save_state
from .telegram import send_message


def _drop_incomplete(candles, granularity_seconds):
    """Never act on a candle that might still be forming."""
    now = datetime.now(timezone.utc)
    return [c for c in candles if c.open_time + timedelta(seconds=granularity_seconds) <= now]


async def gather_candles(symbol: str, app_id: str, counts: dict):
    d1 = await fetch_candles(symbol, GRANULARITY_SECONDS["D1"], counts.get("D1", 400), app_id)
    h4 = await fetch_candles(symbol, GRANULARITY_SECONDS["H4"], counts.get("H4", 300), app_id)
    d1 = _drop_incomplete(d1, GRANULARITY_SECONDS["D1"])
    h4 = _drop_incomplete(h4, GRANULARITY_SECONDS["H4"])

    w1 = aggregate_to_weekly(d1)
    if w1 and w1[-1].open_time > datetime.now(timezone.utc) - timedelta(days=7):
        w1 = w1[:-1]  # drop the still-open current week

    return {"D1": d1, "H4": h4, "W1": w1}


async def run():
    token = os.environ["TELEGRAM_BOT_TOKEN"]
    chat_id = os.environ["TELEGRAM_CHAT_ID"]
    app_id = os.environ.get("DERIV_APP_ID", "1089")

    settings = load_settings()
    instruments = load_instruments()
    state = load_state()

    tz_name = settings.get("timezone", "UTC")
    swing_width = settings.get("swing_width", 1)
    internal_bo_enabled = settings.get("internal_bo_enabled", False)
    erl_enabled = settings.get("erl_enabled", True)
    max_age = settings.get("max_rejection_age_hours", 30)
    counts = settings.get("candle_counts", {"D1": 400, "H4": 300})
    pairs = settings.get("timeframe_pairs", [
        {"higher": "D1", "lower": "H4"},
        {"higher": "W1", "lower": "D1"},
    ])

    for inst in instruments:
        try:
            tf_candles = await gather_candles(inst.deriv_symbol, app_id, counts)
        except Exception as exc:
            print(f"[{inst.name}] failed to fetch candles: {exc}", file=sys.stderr)
            continue

        for pair in pairs:
            higher_tf, lower_tf = pair["higher"], pair["lower"]
            higher_candles = tf_candles.get(higher_tf, [])
            lower_candles = tf_candles.get(lower_tf, [])
            if len(higher_candles) < 10 or len(lower_candles) < 10:
                continue

            try:
                alerts = analyse_pair(
                    inst.name, higher_tf, lower_tf, higher_candles, lower_candles,
                    swing_width, internal_bo_enabled, erl_enabled, max_age,
                )
            except Exception as exc:
                print(f"[{inst.name} {higher_tf}->{lower_tf}] analysis error: {exc}", file=sys.stderr)
                continue

            for alert in alerts:
                bo = alert.external_bo or alert.internal_bo
                bo_kind = "external" if alert.external_bo else "internal"
                key = alert_key(inst.name, higher_tf, lower_tf, alert.bias, bo_kind)
                fingerprint = f"{alert.rejection.candle.open_time.isoformat()}|{bo.breakout_candle.open_time.isoformat()}"

                if already_sent(state, key, fingerprint):
                    continue

                text = format_alert(alert, tz_name)
                try:
                    send_message(token, chat_id, text)
                    mark_sent(state, key, fingerprint)
                    print(f"Sent: {key}")
                except Exception as exc:
                    print(f"[{inst.name}] telegram send failed: {exc}", file=sys.stderr)

    save_state(state)


def main():
    asyncio.run(run())


if __name__ == "__main__":
    main()
