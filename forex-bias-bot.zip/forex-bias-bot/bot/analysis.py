"""Ties key levels, swing structure, trend and ERL together into Alerts.

Pipeline per instrument per timeframe pair (e.g. D1 -> H4):
  1. Find a rejection: does the most recently closed HIGHER-tf candle touch
     a fresh key level and close back away from it?
  2. Find the moment price on the LOWER tf first reached that key level
     (this must happen inside the rejecting candle's own time span, since
     the level was fresh - this is its first touch).
  3. External BO: the last proper swing point of the opposite kind BEFORE
     that reach, on the lower tf - confirmed the moment a later candle
     CLOSES beyond it.
  4. Internal BO (only if enabled): the first proper swing point of the
     opposite kind AFTER that reach - confirmed the same way, earlier and
     weaker.
  5. Trend: break-of-structure direction on the HIGHER tf.
  6. ERL: the most extreme (not nearest) opposite-side swing on the HIGHER
     tf before the key level - "taken" if price has already traded through
     it by the time the breakout candle closes.
"""
from datetime import datetime, timedelta, timezone
from typing import List, Optional

from .models import Candle, RejectionEvent, BreakoutEvent, Alert, SwingPoint, KeyLevel
from .key_levels import detect_key_levels, freshest_untested_levels
from .market_structure import find_swings, last_swing_before, most_extreme_before, determine_trend

GRANULARITY_SECONDS = {"H4": 4 * 3600, "D1": 24 * 3600, "W1": 7 * 24 * 3600}


def find_latest_rejection(higher_candles: List[Candle], max_age_hours: int) -> Optional[RejectionEvent]:
    if len(higher_candles) < 4:
        return None

    idx = len(higher_candles) - 1
    candle = higher_candles[idx]

    if datetime.now(timezone.utc) - candle.open_time > timedelta(hours=max_age_hours):
        return None

    levels = detect_key_levels(higher_candles[: idx + 1])
    fresh = freshest_untested_levels(levels, higher_candles, idx)

    best = None
    for kl in fresh:
        if kl.kind == "resistance" and candle.high >= kl.price and candle.close < kl.price:
            if best is None or kl.price < best.price:
                best = kl
        if kl.kind == "support" and candle.low <= kl.price and candle.close > kl.price:
            if best is None or kl.price > best.price:
                best = kl

    if best is None:
        return None

    bias = "SELL" if best.kind == "resistance" else "BUY"
    prev = higher_candles[idx - 1]
    swept_previous = (
        (bias == "SELL" and candle.high > prev.high and candle.close < prev.high)
        or (bias == "BUY" and candle.low < prev.low and candle.close > prev.low)
    )

    return RejectionEvent(candle_index=idx, candle=candle, key_level=best, bias=bias, swept_previous=swept_previous)


def _find_reach_index(lower_candles: List[Candle], bias: str, kl_price: float,
                       window_start: datetime, window_end: datetime) -> Optional[int]:
    for i, c in enumerate(lower_candles):
        if not (window_start <= c.open_time < window_end):
            continue
        if bias == "SELL" and c.high >= kl_price:
            return i
        if bias == "BUY" and c.low <= kl_price:
            return i
    return None


def _confirm_breakout(lower_candles: List[Candle], bias: str, turning_point: SwingPoint,
                       search_from: int) -> Optional[BreakoutEvent]:
    start = max(turning_point.index, search_from) + 1
    for j in range(start, len(lower_candles)):
        c = lower_candles[j]
        if bias == "SELL" and c.close < turning_point.price:
            return BreakoutEvent(kind="", turning_point_price=turning_point.price,
                                  turning_point_time=turning_point.open_time,
                                  breakout_candle=c, breakout_index=j)
        if bias == "BUY" and c.close > turning_point.price:
            return BreakoutEvent(kind="", turning_point_price=turning_point.price,
                                  turning_point_time=turning_point.open_time,
                                  breakout_candle=c, breakout_index=j)
    return None


def find_erl_level(higher_candles: List[Candle], kl: KeyLevel, width: int) -> Optional[SwingPoint]:
    swings = find_swings(higher_candles, width=width)
    opposite = "low" if kl.kind == "resistance" else "high"
    return most_extreme_before(swings, kl.index, opposite)


def analyse_pair(instrument: str, higher_tf: str, lower_tf: str,
                  higher_candles: List[Candle], lower_candles: List[Candle],
                  swing_width: int, internal_bo_enabled: bool, erl_enabled: bool,
                  max_rejection_age_hours: int) -> List[Alert]:

    rejection = find_latest_rejection(higher_candles, max_rejection_age_hours)
    if rejection is None:
        return []

    bias = rejection.bias
    kl = rejection.key_level
    higher_gran = GRANULARITY_SECONDS[higher_tf]

    window_start = rejection.candle.open_time
    window_end = window_start + timedelta(seconds=higher_gran)
    reach_idx = _find_reach_index(lower_candles, bias, kl.price, window_start, window_end)
    if reach_idx is None:
        return []  # lower-tf data hasn't caught up to the touch yet

    lower_swings = find_swings(lower_candles, width=swing_width)
    point_kind = "low" if bias == "SELL" else "high"

    ext_point = last_swing_before(lower_swings, reach_idx, point_kind)
    external_bo = _confirm_breakout(lower_candles, bias, ext_point, reach_idx) if ext_point else None

    internal_bo = None
    if internal_bo_enabled:
        after_points = [s for s in lower_swings if s.index > reach_idx and s.kind == point_kind]
        if after_points:
            int_point = min(after_points, key=lambda s: s.index)
            internal_bo = _confirm_breakout(lower_candles, bias, int_point, reach_idx)

    if external_bo is None and internal_bo is None:
        return []

    direction, _ = determine_trend(higher_candles, width=swing_width)
    if direction is None:
        trend_label = f"no {higher_tf} trend confirmed yet"
    elif (direction == "up" and bias == "BUY") or (direction == "down" and bias == "SELL"):
        trend_label = f"aligned with {higher_tf}"
    else:
        trend_label = f"against the {higher_tf} trend"

    now = datetime.now(timezone.utc)
    erl_point = find_erl_level(higher_candles, kl, swing_width) if erl_enabled else None

    def build(bo: BreakoutEvent, kind: str) -> Alert:
        bo.kind = kind
        next_day_rule_ok = bo.breakout_candle.open_time >= window_end

        erl_taken = False
        if erl_point is not None:
            for c in lower_candles[reach_idx: bo.breakout_index + 1]:
                if bias == "SELL" and c.low <= erl_point.price:
                    erl_taken = True
                    break
                if bias == "BUY" and c.high >= erl_point.price:
                    erl_taken = True
                    break

        return Alert(
            instrument=instrument, bias=bias, higher_tf=higher_tf, lower_tf=lower_tf,
            rejection=rejection,
            external_bo=bo if kind == "external" else None,
            internal_bo=bo if kind == "internal" else None,
            trend_label=trend_label, next_day_rule_ok=next_day_rule_ok,
            erl_taken=erl_taken, sent_time=now,
        )

    alerts = []
    if internal_bo is not None:
        alerts.append(build(internal_bo, "internal"))
    if external_bo is not None:
        alerts.append(build(external_bo, "external"))
    return alerts
