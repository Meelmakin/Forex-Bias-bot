"""Minimal async client for the free Deriv WebSocket API.

No account or login is needed to read historical candles - this only ever
calls public market-data endpoints (ticks_history, active_symbols).
"""
import asyncio
import json
from datetime import datetime, timezone
from typing import List

import websockets

from .models import Candle

DERIV_WS_URL = "wss://ws.derivws.com/websockets/v3?app_id={app_id}"


async def fetch_candles(symbol: str, granularity: int, count: int, app_id: str) -> List[Candle]:
    """Fetch up to `count` historical OHLC candles for `symbol`.

    granularity is in seconds (e.g. 14400 for H4, 86400 for D1).
    """
    url = DERIV_WS_URL.format(app_id=app_id)
    request = {
        "ticks_history": symbol,
        "style": "candles",
        "granularity": granularity,
        "count": count,
        "end": "latest",
    }
    async with websockets.connect(url, open_timeout=20, close_timeout=10) as ws:
        await ws.send(json.dumps(request))
        raw = await asyncio.wait_for(ws.recv(), timeout=20)

    data = json.loads(raw)
    if "error" in data:
        raise RuntimeError(f"Deriv API error for {symbol}: {data['error'].get('message')}")

    out = []
    for c in data.get("candles", []):
        out.append(Candle(
            open_time=datetime.fromtimestamp(int(c["epoch"]), tz=timezone.utc),
            open=float(c["open"]),
            high=float(c["high"]),
            low=float(c["low"]),
            close=float(c["close"]),
        ))
    out.sort(key=lambda c: c.open_time)
    return out


async def fetch_active_symbols(app_id: str) -> list:
    """Return Deriv's full list of tradable symbols (code + display name)."""
    url = DERIV_WS_URL.format(app_id=app_id)
    request = {"active_symbols": "brief", "product_type": "basic"}
    async with websockets.connect(url, open_timeout=20, close_timeout=10) as ws:
        await ws.send(json.dumps(request))
        raw = await asyncio.wait_for(ws.recv(), timeout=20)

    data = json.loads(raw)
    if "error" in data:
        raise RuntimeError(f"Deriv API error: {data['error'].get('message')}")
    return data.get("active_symbols", [])
