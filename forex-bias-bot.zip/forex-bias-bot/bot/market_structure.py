"""Swing-point (fractal) detection and trend-via-break-of-structure logic.

Confirmed against the user's reference charts:
  * a "turning point" is a proper swing high/low (a fractal), not just the
    previous candle's high/low.
  * the trend flips the moment a candle CLOSES beyond the most recently
    confirmed swing point on the opposite side (a break of structure).
"""
from typing import List, Optional, Tuple

from .models import Candle, SwingPoint


def find_swings(candles: List[Candle], width: int = 1) -> List[SwingPoint]:
    """A swing high at index i: high[i] beats the highs of `width` candles on
    each side. A swing low is the mirror image."""
    swings = []
    n = len(candles)
    for i in range(width, n - width):
        before = candles[i - width:i]
        after = candles[i + 1:i + 1 + width]
        high_i, low_i = candles[i].high, candles[i].low

        if all(high_i > c.high for c in before) and all(high_i > c.high for c in after):
            swings.append(SwingPoint(index=i, open_time=candles[i].open_time, price=high_i, kind="high"))
        if all(low_i < c.low for c in before) and all(low_i < c.low for c in after):
            swings.append(SwingPoint(index=i, open_time=candles[i].open_time, price=low_i, kind="low"))

    swings.sort(key=lambda s: s.index)
    return swings


def last_swing_before(swings: List[SwingPoint], index: int, kind: str) -> Optional[SwingPoint]:
    """Most recent confirmed swing of `kind` strictly before candle `index`."""
    candidates = [s for s in swings if s.index < index and s.kind == kind]
    if not candidates:
        return None
    return max(candidates, key=lambda s: s.index)


def most_extreme_before(swings: List[SwingPoint], index: int, kind: str) -> Optional[SwingPoint]:
    """The most extreme (lowest low / highest high) swing of `kind` strictly
    before candle `index` - used for the ERL "outer edge of the range" level,
    as opposed to last_swing_before which gives the nearest one."""
    candidates = [s for s in swings if s.index < index and s.kind == kind]
    if not candidates:
        return None
    if kind == "low":
        return min(candidates, key=lambda s: s.price)
    return max(candidates, key=lambda s: s.price)


def determine_trend(candles: List[Candle], width: int = 1) -> Tuple[Optional[str], Optional[int]]:
    """Walks forward through confirmed swings; the trend becomes "up" the
    moment a close breaks above the most recently known swing high, and
    "down" the moment a close breaks below the most recently known swing
    low. Returns (direction, index of the candle that confirmed the latest
    change), or (None, None) if no break of structure has happened yet."""
    swings = find_swings(candles, width=width)
    if not swings:
        return None, None

    direction = None
    changed_at = None
    swing_idx = 0
    known_high = None
    known_low = None

    for i, c in enumerate(candles):
        while swing_idx < len(swings) and swings[swing_idx].index < i:
            s = swings[swing_idx]
            if s.kind == "high":
                known_high = s
            else:
                known_low = s
            swing_idx += 1

        if known_high is not None and c.close > known_high.price and direction != "up":
            direction = "up"
            changed_at = i
        elif known_low is not None and c.close < known_low.price and direction != "down":
            direction = "down"
            changed_at = i

    return direction, changed_at
