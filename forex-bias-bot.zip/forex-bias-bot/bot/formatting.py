"""Formats an Alert into the Telegram message text.

Layout confirmed against a real alert the user sent back from Telegram -
match that exactly rather than the original draft layout.
"""
from datetime import datetime
from zoneinfo import ZoneInfo

from .models import Alert

SHAPE_NAME = {"A": "A-shape", "V": "V-shape", "OC": "Open-Close"}


def _fmt_time(dt: datetime, tz: ZoneInfo) -> str:
    return dt.astimezone(tz).strftime("%a %d %b, %H:%M")


def _fmt_price(price: float) -> str:
    return f"{price:.5f}"


def format_alert(alert: Alert, tz_name: str) -> str:
    tz = ZoneInfo(tz_name)
    r = alert.rejection
    kl = r.key_level
    bo = alert.external_bo or alert.internal_bo
    bo_label = "External" if alert.external_bo else "Internal"

    lines = []
    lines.append(f"🚨 {alert.bias} · {alert.instrument} · {alert.higher_tf}→{alert.lower_tf}")
    lines.append(f"{bo_label} breakout confirmed")
    lines.append("")

    lines.append(f"Rejected at {SHAPE_NAME[kl.shape]} KL @ {_fmt_price(kl.price)}.")
    if r.swept_previous:
        if alert.bias == "SELL":
            lines.append("Swept previous candle high, closed back below")
        else:
            lines.append("Swept previous candle low, closed back above")

    lines.append("")
    lines.append(f"{bo_label} BO @ {_fmt_price(bo.turning_point_price)} · {_fmt_time(bo.breakout_candle.open_time, tz)}")
    lines.append(f"Rejected on {_fmt_time(r.candle.open_time, tz)}")
    lines.append(f"Trend {alert.trend_label}")

    if alert.next_day_rule_ok:
        lines.append("✅ Next Day Rule · breakout after the rejection candle closed")
    if alert.erl_taken:
        lines.append("⚠️ ERL taken")

    lines.append("")
    lines.append("All times shown are candle open times.")
    lines.append("")
    lines.append("⚠️ Not an entry signal. Bias only — wait for your entry model.")
    lines.append("")

    sent_local = alert.sent_time.astimezone(tz)
    lines.append(f"Sent {sent_local.strftime('%d %b, %-I:%M %p')} {sent_local.strftime('%Z')}")

    return "\n".join(lines)
