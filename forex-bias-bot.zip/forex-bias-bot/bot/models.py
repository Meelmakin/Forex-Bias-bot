"""Shared dataclasses used across the bot."""
from dataclasses import dataclass
from datetime import datetime
from typing import Literal, Optional


@dataclass
class Candle:
    open_time: datetime  # UTC, candle OPEN time
    open: float
    high: float
    low: float
    close: float

    @property
    def bullish(self) -> bool:
        return self.close > self.open

    @property
    def bearish(self) -> bool:
        return self.close < self.open


@dataclass
class SwingPoint:
    index: int
    open_time: datetime
    price: float
    kind: Literal["high", "low"]


@dataclass
class KeyLevel:
    index: int              # index of the FIRST candle of the 2-candle formation
    formed_time: datetime   # open time of that first candle
    confirmed_index: int    # index of the second candle (formation confirmed on its close)
    price: float
    kind: Literal["resistance", "support"]  # resistance -> SELL bias, support -> BUY bias
    shape: Literal["A", "V", "OC"]


@dataclass
class RejectionEvent:
    candle_index: int
    candle: Candle
    key_level: KeyLevel
    bias: Literal["BUY", "SELL"]
    swept_previous: bool


@dataclass
class BreakoutEvent:
    kind: str  # "external" | "internal"
    turning_point_price: float
    turning_point_time: datetime
    breakout_candle: Candle
    breakout_index: int


@dataclass
class Alert:
    instrument: str
    bias: Literal["BUY", "SELL"]
    higher_tf: str
    lower_tf: str
    rejection: RejectionEvent
    external_bo: Optional[BreakoutEvent]
    internal_bo: Optional[BreakoutEvent]
    trend_label: str
    next_day_rule_ok: bool
    erl_taken: bool
    sent_time: datetime
