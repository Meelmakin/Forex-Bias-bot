"""Key level (KL) detection and freshness.

Confirmed against the user's reference charts:
  * A-shape = rising candle then falling candle (a peak) -> resistance KL,
    SELL-side. Level = the higher of the two candles' highs.
  * V-shape = falling candle then rising candle (a trough) -> support KL,
    BUY-side. Level = the lower of the two candles' lows.
  * Open-Close = two candles in a row moving the SAME direction
    (confirmed) - the level is the price where the first candle's CLOSE
    meets the second candle's OPEN (the same point in a continuous feed).
    Two bearish candles -> resistance above price; two bullish candles ->
    support below price.
  * Freshness: CONFIRMED by the user's chart - a level stops being fresh
    the moment any later candle's WICK touches it, or price trades through
    it - not only on a close through it.
"""
from typing import List

from .models import Candle, KeyLevel


def detect_key_levels(candles: List[Candle]) -> List[KeyLevel]:
    levels = []
    for i in range(len(candles) - 1):
        c1, c2 = candles[i], candles[i + 1]

        if c1.bullish and c2.bearish:
            levels.append(KeyLevel(
                index=i, formed_time=c1.open_time, confirmed_index=i + 1,
                price=max(c1.high, c2.high), kind="resistance", shape="A",
            ))
        elif c1.bearish and c2.bullish:
            levels.append(KeyLevel(
                index=i, formed_time=c1.open_time, confirmed_index=i + 1,
                price=min(c1.low, c2.low), kind="support", shape="V",
            ))
        elif c1.bearish and c2.bearish:
            levels.append(KeyLevel(
                index=i, formed_time=c1.open_time, confirmed_index=i + 1,
                price=c1.close, kind="resistance", shape="OC",
            ))
        elif c1.bullish and c2.bullish:
            levels.append(KeyLevel(
                index=i, formed_time=c1.open_time, confirmed_index=i + 1,
                price=c1.close, kind="support", shape="OC",
            ))
    return levels


def is_fresh(kl: KeyLevel, candles: List[Candle], upto_index: int) -> bool:
    """A KL is fresh if no candle between its confirmation and `upto_index`
    (exclusive) has a wick that reached, or traded through, its price."""
    for j in range(kl.confirmed_index + 1, upto_index):
        c = candles[j]
        if kl.kind == "resistance" and c.high >= kl.price:
            return False
        if kl.kind == "support" and c.low <= kl.price:
            return False
    return True


def freshest_untested_levels(levels: List[KeyLevel], candles: List[Candle], upto_index: int) -> List[KeyLevel]:
    return [kl for kl in levels if kl.confirmed_index < upto_index and is_fresh(kl, candles, upto_index)]
