"""Loads config/instruments.yaml and config/settings.yaml."""
import os
from dataclasses import dataclass
from typing import Any, Dict, List

import yaml

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_DIR = os.path.join(BASE_DIR, "config")


@dataclass
class Instrument:
    name: str
    deriv_symbol: str
    enabled: bool = True


def load_instruments() -> List[Instrument]:
    path = os.path.join(CONFIG_DIR, "instruments.yaml")
    with open(path, "r") as f:
        data = yaml.safe_load(f) or {}
    items = data.get("instruments", [])
    return [Instrument(name=i["name"], deriv_symbol=i["deriv_symbol"], enabled=i.get("enabled", True))
            for i in items if i.get("enabled", True)]


def load_settings() -> Dict[str, Any]:
    path = os.path.join(CONFIG_DIR, "settings.yaml")
    with open(path, "r") as f:
        return yaml.safe_load(f) or {}
